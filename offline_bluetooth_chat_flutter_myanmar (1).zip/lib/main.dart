import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'services/bluetooth_service.dart';
import 'services/db_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FireChatApp());
}

class FireChatApp extends StatelessWidget {
  const FireChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    final baseTheme = ThemeData.dark(useMaterial3: true);
    const myanmarFallbacks = <String>[
      'Noto Sans Myanmar',
      'Myanmar Text',
      'sans-serif',
    ];

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FireChat',
      locale: const Locale('my'),
      supportedLocales: const [Locale('my'), Locale('en')],
      theme: baseTheme.copyWith(
        fontFamilyFallback: myanmarFallbacks,
        textTheme: baseTheme.textTheme.apply(
          fontFamilyFallback: myanmarFallbacks,
        ),
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.cyan,
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF0B1014),
      ),
      home: HomeScreen(
        bluetooth: BluetoothService.instance,
        database: DbService.instance,
      ),
    );
  }
}
