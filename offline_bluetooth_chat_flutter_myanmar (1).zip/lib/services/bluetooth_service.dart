import 'dart:async';
import 'dart:convert';

import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

/// Coordinates BLE permissions, discovery, connection, and message transport.
class BluetoothService {
  BluetoothService._();

  static final BluetoothService instance = BluetoothService._();

  final StreamController<BluetoothDevice> _discoveredDevicesController =
      StreamController<BluetoothDevice>.broadcast();
  final StreamController<String> _incomingMessagesController =
      StreamController<String>.broadcast();

  StreamSubscription<List<ScanResult>>? _scanSubscription;
  StreamSubscription<List<int>>? _incomingSubscription;
  final Set<String> _discoveredDeviceIds = <String>{};
  BluetoothDevice? _connectedDevice;
  BluetoothCharacteristic? _writeCharacteristic;
  BluetoothCharacteristic? _incomingCharacteristic;
  bool _isScanning = false;

  /// Emits each nearby BLE device once per scan session.
  Stream<BluetoothDevice> get discoveredDevices =>
      _discoveredDevicesController.stream;

  /// Emits decoded text received from the remote device.
  Stream<String> get incomingMessages => _incomingMessagesController.stream;

  /// Requests the Bluetooth and location permissions needed for BLE scanning.
  Future<bool> requestScanPermissions() async {
    final statuses = await <Permission>[
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse,
    ].request();

    return statuses.values.every((status) => status.isGranted);
  }

  /// Starts scanning and emits newly discovered devices through the stream.
  Future<void> startScan() async {
    if (_isScanning) return;

    if (!await requestScanPermissions()) {
      throw StateError('Bluetooth and location permissions are required.');
    }
    if (await FlutterBluePlus.adapterState.first != BluetoothAdapterState.on) {
      throw StateError('Bluetooth must be enabled to scan.');
    }

    _discoveredDeviceIds.clear();
    _isScanning = true;
    _scanSubscription = FlutterBluePlus.scanResults.listen((results) {
      for (final result in results) {
        if (_discoveredDeviceIds.add(result.device.remoteId.str)) {
          _discoveredDevicesController.add(result.device);
        }
      }
    });

    try {
      await FlutterBluePlus.startScan();
    } catch (_) {
      await stopScan();
      rethrow;
    }
  }

  /// Stops the active BLE scan.
  Future<void> stopScan() async {
    if (!_isScanning && _scanSubscription == null) return;

    await FlutterBluePlus.stopScan();
    await _scanSubscription?.cancel();
    _scanSubscription = null;
    _isScanning = false;
  }

  /// Connects to [device], discovers GATT characteristics, and subscribes to
  /// notifications from the first notify/indicate characteristic found.
  Future<void> connectToDevice(BluetoothDevice device) async {
    await disconnectFromDevice();
    await stopScan();

    await device.connect();
    _connectedDevice = device;

    try {
      final services = await device.discoverServices();
      for (final service in services) {
        for (final characteristic in service.characteristics) {
          final properties = characteristic.properties;
          _writeCharacteristic ??= properties.write ||
                  properties.writeWithoutResponse
              ? characteristic
              : null;
          _incomingCharacteristic ??= properties.notify || properties.indicate
              ? characteristic
              : null;
        }
      }

      final incoming = _incomingCharacteristic;
      if (_writeCharacteristic == null) {
        throw StateError('No writable GATT characteristic was found.');
      }

      if (incoming != null) {
        await incoming.setNotifyValue(true);
        _incomingSubscription = incoming.onValueReceived.listen((bytes) {
          if (bytes.isNotEmpty) {
            _incomingMessagesController.add(utf8.decode(bytes));
          }
        });
      }
    } catch (_) {
      await disconnectFromDevice();
      rethrow;
    }
  }

  /// Encodes [text] as UTF-8 and writes it to the discovered GATT characteristic.
  Future<void> sendMessage(String text) async {
    final characteristic = _writeCharacteristic;
    if (_connectedDevice == null || characteristic == null) {
      throw StateError('No connected device with a writable characteristic.');
    }

    final properties = characteristic.properties;
    await characteristic.write(
      utf8.encode(text),
      withoutResponse: !properties.write && properties.writeWithoutResponse,
    );
  }

  /// Disconnects the current device and clears discovered characteristics.
  Future<void> disconnectFromDevice() async {
    await _incomingSubscription?.cancel();
    _incomingSubscription = null;
    _writeCharacteristic = null;
    _incomingCharacteristic = null;

    final device = _connectedDevice;
    _connectedDevice = null;
    if (device != null) await device.disconnect();
  }

  /// Releases all resources owned by this service.
  Future<void> dispose() async {
    await stopScan();
    await disconnectFromDevice();
    await _discoveredDevicesController.close();
    await _incomingMessagesController.close();
  }
}
