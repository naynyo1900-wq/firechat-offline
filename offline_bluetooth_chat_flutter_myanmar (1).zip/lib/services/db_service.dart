import 'package:sqflite/sqflite.dart';

/// Stores chat messages locally for offline use.
class DbService {
  DbService._();

  static final DbService instance = DbService._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;

    final path = '${await getDatabasesPath()}/offline_chat.db';
    _database = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT NOT NULL,
            sender_id TEXT NOT NULL,
            timestamp INTEGER NOT NULL,
            status TEXT NOT NULL
          )
        ''');
      },
    );
    return _database!;
  }

  /// Saves a message and returns its local database ID.
  Future<int> insertMessage({
    required String text,
    required String senderId,
    required DateTime timestamp,
    required String status,
  }) async {
    final db = await database;
    return db.insert('messages', {
      'text': text,
      'sender_id': senderId,
      'timestamp': timestamp.millisecondsSinceEpoch,
      'status': status,
    });
  }

  /// Returns messages in chronological order.
  Future<List<Map<String, Object?>>> getMessages() async {
    final db = await database;
    return db.query('messages', orderBy: 'timestamp ASC, id ASC');
  }

  /// Updates delivery state without changing the message contents.
  Future<int> updateMessageStatus(int id, String status) async {
    final db = await database;
    return db.update(
      'messages',
      {'status': status},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> close() async {
    await _database?.close();
    _database = null;
  }
}
