import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

import '../services/bluetooth_service.dart';
import '../services/db_service.dart';
import 'chat_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.bluetooth,
    required this.database,
  });

  final BluetoothService bluetooth;
  final DbService database;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _radarController;
  StreamSubscription<BluetoothDevice>? _deviceSubscription;
  final List<BluetoothDevice> _devices = <BluetoothDevice>[];
  bool _scanning = false;

  @override
  void initState() {
    super.initState();
    _radarController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();
    _deviceSubscription = widget.bluetooth.discoveredDevices.listen((device) {
      if (!mounted || _devices.any((item) => item.remoteId == device.remoteId)) {
        return;
      }
      setState(() => _devices.add(device));
    });
  }

  Future<void> _toggleScan() async {
    try {
      if (_scanning) {
        await widget.bluetooth.stopScan();
      } else {
        setState(() => _devices.clear());
        await widget.bluetooth.startScan();
      }
      if (mounted) setState(() => _scanning = !_scanning);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.toString())),
        );
      }
    }
  }

  Future<void> _connect(BluetoothDevice device) async {
    try {
      await widget.bluetooth.connectToDevice(device);
      if (!mounted) return;
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ChatScreen(
            device: device,
            bluetooth: widget.bluetooth,
            database: widget.database,
          ),
        ),
      );
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Connection failed: $error')),
        );
      }
    }
  }

  @override
  void dispose() {
    _deviceSubscription?.cancel();
    _radarController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('FireChat'),
        centerTitle: false,
      ),
      body: Column(
        children: [
          const SizedBox(height: 12),
          AnimatedBuilder(
            animation: _radarController,
            builder: (_, __) => SizedBox(
              height: 220,
              width: 220,
              child: CustomPaint(painter: RadarPainter(_radarController.value)),
            ),
          ),
          Text(
            _scanning ? 'စက်များ ရှာဖွေနေသည်...' : 'အနီးအနားရှိ စက်များ',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _toggleScan,
            icon: Icon(_scanning ? Icons.stop : Icons.radar),
            label: Text(_scanning ? 'ရပ်မည်' : 'စက်များ ရှာဖွေမည်'),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: _devices.isEmpty
                ? const Center(child: Text('အနီးအနားတွင် စက်မတွေ့ပါ'))
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: _devices.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, index) {
                      final device = _devices[index];
                      final name = device.platformName.isEmpty
                          ? device.remoteId.str
                          : device.platformName;
                      return Card(
                        child: ListTile(
                          leading: const Icon(Icons.bluetooth),
                          title: Text(name),
                          subtitle: Text(device.remoteId.str),
                          trailing: TextButton(
                            onPressed: () => _connect(device),
                            child: const Text('ချိတ်ဆက်မည်'),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class RadarPainter extends CustomPainter {
  RadarPainter(this.progress);

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.shortestSide / 2;
    final line = Paint()
      ..color = Colors.cyanAccent.withOpacity(.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    final sweep = Paint()
      ..shader = SweepGradient(
        colors: [Colors.cyanAccent.withOpacity(.45), Colors.transparent],
      ).createShader(Offset.zero & size);

    for (final scale in [.35, .65, .95]) {
      canvas.drawCircle(center, radius * scale, line);
    }
    canvas.drawLine(
      Offset(center.dx, center.dy - radius),
      Offset(center.dx, center.dy + radius),
      line,
    );
    canvas.drawLine(
      Offset(center.dx - radius, center.dy),
      Offset(center.dx + radius, center.dy),
      line,
    );
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(progress * 6.283);
    canvas.drawArc(
      Rect.fromCircle(center: Offset.zero, radius: radius),
      -0.8,
      0.8,
      true,
      sweep,
    );
    canvas.restore();
    canvas.drawCircle(center, 4, Paint()..color = Colors.cyanAccent);
  }

  @override
  bool shouldRepaint(RadarPainter oldDelegate) => oldDelegate.progress != progress;
}
