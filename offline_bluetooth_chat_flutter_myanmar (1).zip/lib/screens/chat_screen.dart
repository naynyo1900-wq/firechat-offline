import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

import '../services/bluetooth_service.dart';
import '../services/db_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({
    super.key,
    required this.device,
    required this.bluetooth,
    required this.database,
  });

  final BluetoothDevice device;
  final BluetoothService bluetooth;
  final DbService database;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _input = TextEditingController();
  final List<_Message> _messages = <_Message>[];
  StreamSubscription<String>? _incomingSubscription;

  @override
  void initState() {
    super.initState();
    _loadHistory();
    _incomingSubscription = widget.bluetooth.incomingMessages.listen((text) {
      final message = _utf8Text(text);
      _addMessage(message, false);
      widget.database.insertMessage(
        text: message,
        senderId: widget.device.remoteId.str,
        timestamp: DateTime.now(),
        status: 'received',
      );
    });
  }

  // Keeps every UI/database string valid Unicode at the Bluetooth boundary.
  String _utf8Text(String value) => utf8.decode(utf8.encode(value));

  Future<void> _loadHistory() async {
    final rows = await widget.database.getMessages();
    if (!mounted) return;
    setState(() {
      _messages.addAll(rows.map((row) => _Message(
            text: _utf8Text(row['text']! as String),
            sent: row['status'] != 'received',
          )));
    });
  }

  void _addMessage(String text, bool sent) {
    if (mounted) setState(() => _messages.add(_Message(text: text, sent: sent)));
  }

  Future<void> _send() async {
    final text = _utf8Text(_input.text.trim());
    if (text.isEmpty) return;

    try {
      // BluetoothService converts this Unicode string to UTF-8 bytes before write.
      await widget.bluetooth.sendMessage(text);
      _input.clear();
      _addMessage(text, true);
      await widget.database.insertMessage(
        text: text,
        senderId: 'me',
        timestamp: DateTime.now(),
        status: 'sent',
      );
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Message failed: $error')),
        );
      }
    }
  }

  @override
  void dispose() {
    _incomingSubscription?.cancel();
    _input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final name = widget.device.platformName.isEmpty
        ? widget.device.remoteId.str
        : widget.device.platformName;
    return Scaffold(
      appBar: AppBar(title: Text(name)),
      body: Column(
        children: [
          Expanded(
            child: _messages.isEmpty
                ? const Center(child: Text('စာတိုမရှိသေးပါ'))
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _messages.length,
                    itemBuilder: (_, index) {
                      final message = _messages[index];
                      return Align(
                        alignment: message.sent
                            ? Alignment.centerRight
                            : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: message.sent
                                ? Colors.cyan.shade800
                                : Colors.grey.shade800,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text(message.text),
                        ),
                      );
                    },
                  ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _input,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      decoration: const InputDecoration(
                        hintText: 'စာတိုရိုက်ပါ',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: _send,
                    icon: const Icon(Icons.send),
                    tooltip: 'ပို့မည်',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Message {
  const _Message({required this.text, required this.sent});

  final String text;
  final bool sent;
}
